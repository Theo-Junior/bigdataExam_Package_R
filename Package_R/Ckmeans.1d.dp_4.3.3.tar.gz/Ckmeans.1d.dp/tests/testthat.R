# testthat.R -- automated test cases
#
# MS
# Created: Feb 8, 2015

require("testthat")
require("Ckmeans.1d.dp")

test_check("Ckmeans.1d.dp")
