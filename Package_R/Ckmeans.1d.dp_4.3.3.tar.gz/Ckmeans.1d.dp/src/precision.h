// typedef long double ldouble;
typedef double ldouble;
