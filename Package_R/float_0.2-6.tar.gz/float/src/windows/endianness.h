#ifndef SPM_ENDIANNESS_H_
#define SPM_ENDIANNESS_H_


// This assumes your windows box is little endian. If big endian, set to 1.
#define SPM_BOBE 0


#endif
