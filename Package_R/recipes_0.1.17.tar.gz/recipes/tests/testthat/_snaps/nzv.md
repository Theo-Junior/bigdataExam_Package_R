# altered freq_cut and unique_cut

    The `options` argument of `step_nzv()` was deprecated in recipes 0.1.7 and is now defunct.
    Please use the arguments `freq_cut` and `unique_cut` instead.

