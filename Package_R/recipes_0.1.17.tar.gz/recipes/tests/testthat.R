library(testthat)
library(recipes)

test_check("recipes")
