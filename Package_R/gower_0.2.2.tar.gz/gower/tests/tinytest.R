library(gower)
if ( require(tinytest) ){
   test_package("gower")
}

